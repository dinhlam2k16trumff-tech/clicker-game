let score = 0;
let power = 1;
let auto = 0;

const scoreEl = document.getElementById("score");
const infoEl = document.getElementById("info");
const log = document.getElementById("log");
const btn = document.getElementById("clickBtn");

/* LOAD SAVE */
if (localStorage.save) {
  let data = JSON.parse(localStorage.save);
  score = data.score;
  power = data.power;
  auto = data.auto;
}

/* SAVE */
function save() {
  localStorage.save = JSON.stringify({
    score, power, auto
  });
}

/* UPDATE */
function update() {
  scoreEl.innerText = Math.floor(score);
  infoEl.innerText = "Power: " + power + " | Auto: " + auto;
  save();
}

/* CLICK */
btn.onclick = () => {
  let crit = Math.random() < 0.2 ? 2 : 1;

  let gain = power * crit;
  score += gain;

  if (crit > 1) {
    log.innerText = "💥 CRIT x2!";
  } else {
    log.innerText = "+" + gain;
  }

  btn.style.transform = "scale(0.8)";
  setTimeout(() => {
    btn.style.transform = "scale(1)";
  }, 100);

  update();
};

/* POWER */
function buyPower() {
  if (score >= 100) {
    score -= 100;
    power++;
    log.innerText = "⚡ Power tăng!";
  } else {
    log.innerText = "❌ Không đủ điểm";
  }
  update();
}

/* AUTO */
function buyAuto() {
  if (score >= 200) {
    score -= 200;
    auto++;
    log.innerText = "🤖 Auto tăng!";
  } else {
    log.innerText = "❌ Không đủ điểm";
  }
  update();
}

/* AUTO LOOP */
setInterval(() => {
  score += auto;
  update();
}, 1000);

/* SPIN */
function spin() {
  let r = Math.random();

  if (r < 0.5) {
    let win = Math.floor(Math.random() * 300);
    score += win;
    log.innerText = "🎉 +" + win;
  } else {
    let lose = Math.floor(Math.random() * 150);
    score -= lose;
    log.innerText = "💀 -" + lose;
  }

  update();
}

/* RESET */
function resetGame() {
  if (confirm("Reset game?")) {
    score = 0;
    power = 1;
    auto = 0;
    localStorage.clear();
    update();
  }
}

/* INIT */
update();